<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ShowroomController extends Controller
{
    public function Showroom(){
        return view('Showroom.Showroom');
    }
}
